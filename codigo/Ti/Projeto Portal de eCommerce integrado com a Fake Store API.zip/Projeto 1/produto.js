function carregarid()
{
let url=new URLSearchParams(window.location.search)
produto=url.get("Produto")
api=`https://diwserver.vps.webdock.cloud/products/${produto}`
fetch(api)
.then(res => res.json())
.then(data => document.getElementById("produto").innerHTML = `<img src="${data.image}" alt="Imagem do Produto" class="product-image prodlim">

    <div class="product-info">
        <h2>${data.title}</h2>
       
    </div>

    <div class="product-details">
        <div>
            <strong>Preço:</strong>
            <span>USD${data.price}</span>
        </div>
        <div>
            <strong>Marca:</strong>
            <span>${data.brandName}</span>
        </div>
        <div>
            <strong>cor</strong>
            <span>${data.baseColour}</span>
        </div>
        <div class="text-dark">
            <strong>descrição:</strong>
            <span>${data.description}</span>
        </div>
        <div>
            <strong>genero:</strong>
            <span>${data.gender}</span>
        </div>
        <div>
            <strong>Ano:</strong>
            <span>${data.year}</span>
        </div>
    </div>

    <button class="button">Adicionar ao Carrinho</button>`
)

}
carregarid()
function redirecionarprocura() {
    window.location.href = `pesquisa.html` ;
}