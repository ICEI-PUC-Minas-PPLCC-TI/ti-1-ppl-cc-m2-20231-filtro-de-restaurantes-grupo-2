function exemplo() {
    let prod = ``;

    for (x = 1; x < 28; x++) {
        let url = `https://diwserver.vps.webdock.cloud/products/category/Accessories - Wallets?page=${x}`;
        fetch(url)
            .then(res => res.json())
            .then(data => {

                for (let i = 0; i < data.products.length; i++) {

                    prod += `<div class="col-lg-3 col-md-6 col-sm-12   card card-bottles mx-3 mt-3">
                <img src="${data.products[i].image}" class="card-img-top cardslim" alt="Black Bottle" >
                <div class="card-body">
                <h5 class="card-title">${data.products[i].title}</h5>
                <p>Marca:${data.products[i].brandName}</p>
                <p>USD$${data.products[i].price}</p>
                <button class="rounded-pill" onclick="redirecionar(${data.products[i].id})">Saiba Mais</button>
                </div>
                </div>`
                }
                document.getElementById("cards").innerHTML = prod;
            })
    }
}
exemplo()
function moreviwer() {
    let prod = ``;
    for (x = 5; x < 6; x++) {
        let url = `https://diwserver.vps.webdock.cloud/products/category/Accessories - Wallets?page=${x}`;
        fetch(url)
            .then(res => res.json())
            .then(data => {

                for (let i = 0; i < data.products.length - 2; i++) {

                    prod += `<div class="card card-bottles me-3 mt-3">
                    <img src="${data.products[i].image}" class="card-img-top" alt="Grey Bottle" height="400">
                    <div class="card-body">
                    <h5 class="card-title">${data.products[i].title}</h5>
                    <p>Marca:${data.products[i].brandName}</p>
                    <p>USD$${data.products[i].price}</p>
                    </div>
                    </div>`
                }
                prod += `<div class="border border-2 border-secondary mt-3">
                <div class="m-2">
                    <p class="fs-6 mb-0">Últimas notícias</p>
                    <p class="description-card mb-0">Entre para saber as últimas notícias</p>
                    <input type="email" name="email" id="email" class="input-news mt-3">
                    <input type="button" value="Entre Agora!" class="mt-3 description-card bg-secondary-subtle">
                </div>
            </div>`
                document.getElementById("moreviwers").innerHTML = prod;
            })
    }

}
moreviwer()
function redirecionar(id) {
    window.location.href = `produto.html?Produto=${id}`;
}
function search()
{
    cor = document.getElementById("Cor").value
    genero = document.getElementById("genero").value
    let prod = ``;
    for (x = 1; x < 28; x++) {
        let url = `https://diwserver.vps.webdock.cloud/products/category/Accessories - Wallets?page=${x}`;
        fetch(url)
            .then(res => res.json())
            .then(data => {

                for (let i = 0; i < data.products.length; i++) {
                    if (cor.toLowerCase() == data.products[i].baseColour.toLowerCase() || cor == "all") {
                        if (genero.toLowerCase() == data.products[i].gender.toLowerCase() || genero == "neutro") {
                          

                                prod += `<div class="col-lg-3 col-md-6 col-sm-12   card card-bottles mx-3 mt-3">
                    <img src="${data.products[i].image}" class="card-img-top cardslim" alt="Black Bottle" >
                    <div class="card-body">
                    <h5 class="card-title">${data.products[i].title}</h5>
                    <p>Marca:${data.products[i].brandName}</p>
                    <p>USD$${data.products[i].price}</p>
                    <button class="rounded-pill" onclick="redirecionar(${data.products[i].id})">Saiba Mais</button>
                    </div>
                    </div>`
                            
                        }
                    }


                }
                document.getElementById("cards").innerHTML = prod;
            })
    }
}
function redirecionarprocura() {
    window.location.href = `pesquisa.html` ;
}