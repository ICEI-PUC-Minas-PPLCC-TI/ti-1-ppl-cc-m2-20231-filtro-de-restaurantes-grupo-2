function search()
{
    vartxt= document.getElementById("nome-produto").value
    let prod = ``;
    for (x = 1; x < 28; x++) {
        let url = `https://diwserver.vps.webdock.cloud/products/category/Accessories - Wallets?page=${x}`;
        fetch(url)
            .then(res => res.json())
            .then(data => {

                for (let i = 0; i < data.products.length; i++) {
                    if ( (data.products[i].title.toLowerCase().includes(vartxt.toLowerCase())) || vartxt==null ) {
                    

                                prod += `<div class="col-lg-3 col-md-6 col-sm-12   card card-bottles mx-3 mt-3">
                    <img src="${data.products[i].image}" class="card-img-top cardslim" alt="Black Bottle" >
                    <div class="card-body">
                    <h5 class="card-title">${data.products[i].title}</h5>
                    <p>Marca:${data.products[i].brandName}</p>
                    <p>USD$${data.products[i].price}</p>
                    <button class="rounded-pill" onclick="redirecionar(${data.products[i].id})">Saiba Mais</button>
                    </div>
                    </div>`
                            
                        
                    }


                }
                document.getElementById("resultado-pesquisa").innerHTML = prod;
            })
    }
}
function redirecionar(id) {
    window.location.href = `produto.html?Produto=${id}`;
}
search()
